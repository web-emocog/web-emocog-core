# Деплой EmoCog (папка main)

Папка `main` содержит всё необходимое для работы и хостинга приложения.

## Структура после деплоя

- **`index.html`** (в корне main) — редирект на `apps/web/index.html`.
- **`apps/web/`** — главный сайт: лэндинг, исследователь, раздел разработчика (логин, RT/BPM тесты).
- **`apps/participant-web/run_new.html`** — точка входа по приглашению, автоматически перенаправляет в полный MVP flow.
- **`apps/participant-web/mvp_with_precheck_1-updated.html`** — полный MVP: precheck, калибровка, Test Hub.
- **`apps/api/`** — бэкенд API (Node.js). Запуск: `npm run start:phase4` или `node server_phase4_updated.js` из папки `apps/api`.
- **`lib/rppg_alg_qc_test_web_alg_test_v10/`** — движок BPM/rPPG для теста разработчика.

## Настройка при хостинге

1. **Статика**: отдавайте корень сайта с папки `main` (или положите содержимое `main` в корень документа сервера).
2. **API**: поднимите API отдельно (например, на поддомене или по пути `/api`). В консоли на странице исследователя задайте:
   - `window.API_BASE = 'https://your-api.example.com'`
   - `window.API_TOKEN = '...'` (если нужна авторизация)
3. **Респондент по приглашению**: для кнопки Sandbox в разделе Protocols задайте базовый URL страницы участника:
   - `window.PARTICIPANT_RUN_BASE = 'https://your-site.example.com/apps/participant-web'`
   (или относительный путь, например `./apps/participant-web`, если статика и участник на одном домене.)
4. **Респондент (run_new.html)**: на странице участника при необходимости задайте:
   - `window.PROTOCOL_RUN_API_BASE = 'https://your-api.example.com'`  
   чтобы загрузка протокола/стимулов по коду шла на ваш API.

## Запуск API локально

```bash
cd main/apps/api
npm install
node server_phase4_updated.js
```

По умолчанию сервер слушает порт 3000. Проверки доступности:
- `GET /health` — liveness
- `GET /ready` — readiness (с проверкой БД)
Миграции БД — по документации в `apps/api/README.md`.

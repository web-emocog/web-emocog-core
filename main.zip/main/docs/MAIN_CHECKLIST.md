# Проверка полноты папки main перед деплоем

Перед деплоем убедитесь, что в **main** есть все перечисленные элементы. Деплой только этой папки достаточен для работы всего сайта.

---

## Структура (архитектура)

| Путь | Назначение |
|------|------------|
| **apps/web/** | Главный сайт: лэндинг, исследователь, раздел разработчика |
| **apps/participant-web/** | Интерфейс респондента (протоколы, MVP, тесты) |
| **apps/api/** | Бэкенд API (Node.js, Фаза 4) |
| **lib/** | Библиотеки (rPPG/BPM для теста разработчика) |
| **rt_component-/** | Python RT-аналитика (офлайн, опционально) |

---

## Корень main

| Путь | Назначение |
|------|------------|
| `index.html` | Редирект на `apps/web/index.html` |
| `DEPLOY.md`, `HOSTING.md`, `README.md`, `MAIN_CHECKLIST.md` | Документация |

---

## apps/web (главный сайт)

| Путь | Назначение |
|------|------------|
| `apps/web/index.html` | Лэндинг (Исследователь / Респондент / Разработчик) |
| `apps/web/researcher.html` | Интерфейс исследователя |
| `apps/web/researcher_phase3.html` | Резервная версия исследователя |
| `apps/web/developer.html` | Страница тестов разработчика (после входа) |
| `apps/web/developer/login.html` | Вход в раздел разработчика |
| `apps/web/developer/rt-test.html`, `rt-test.js` | Тест Reaction Time |
| `apps/web/developer/bpm-test.html`, `bpm-test.js` | Тест BPM/rPPG |

---

## apps/participant-web

| Путь | Назначение |
|------|------------|
| `apps/participant-web/run_new.html` | Респондент: выполнение протокола по коду |
| `apps/participant-web/mvp_with_precheck_1-updated.html` | Полный MVP |
| `apps/participant-web/style.css`, `translations.js`, `experiment.json` | Стили, переводы, протокол RT |
| `apps/participant-web/test-qc-metrics.html` | Тест QC Metrics |
| `apps/participant-web/tools/session-report.html`, `session-report.js` | Session Report |
| `apps/participant-web/js/` | Все модули (protocol-runner, precheck, gaze, qc-metrics, face-segmenter, web-page и т.д.) |

---

## lib (BPM/rPPG)

| Путь | Назначение |
|------|------------|
| `lib/rppg_alg_qc_test_web_alg_test_v10/rppg_alg/` | Движок rPPG |

Тест BPM (`apps/web/developer/bpm-test.js`) подключает: `../../../lib/rppg_alg_qc_test_web_alg_test_v10/rppg_alg/index.js`.

---

## apps/api

| Путь | Назначение |
|------|------------|
| `apps/api/server_phase4_updated.js` | Точка входа API |
| `apps/api/app_phase4_updated.js` | Express-приложение (Фаза 4) |
| `apps/api/routes/*.js`, `config/`, `db.js`, `middleware/`, `qc/`, `migrations/` | Маршруты, конфиг, БД, миграции |
| `apps/api/package.json`, `.env.example` | Зависимости и пример .env |

---

## Быстрая проверка

```bash
# Из каталога, где лежит main
test -f main/index.html && echo "OK root index" || echo "MISSING"
test -f main/apps/web/index.html && echo "OK web index" || echo "MISSING"
test -f main/apps/web/developer/login.html && echo "OK dev login" || echo "MISSING"
test -f main/apps/participant-web/run_new.html && echo "OK run_new" || echo "MISSING"
test -f main/apps/participant-web/experiment.json && echo "OK experiment.json" || echo "MISSING"
test -f main/apps/api/server_phase4_updated.js && echo "OK api" || echo "MISSING"
test -f main/lib/rppg_alg_qc_test_web_alg_test_v10/rppg_alg/index.js && echo "OK rppg" || echo "MISSING"
```

Все команды должны вывести `OK`.

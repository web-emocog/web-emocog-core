# Развёртывание EmoCog на виртуальной машине

Пошаговая инструкция: один сайт (статический фронт + API за nginx), хостинг на VM.

---

## 1. Что будет на VM

| Компонент | Назначение |
|-----------|------------|
| **Nginx** | Раздача статики (папка `main`) и проксирование запросов к API |
| **Node.js API** | Бэкенд (порт 3000 внутри VM), доступ по `https://ваш-домен/api` |
| **PostgreSQL** | База данных для API (пользователи, сессии, протоколы, приглашения) |

Итог: один домен, например `https://emocog.example.com` — лэндинг, исследователь, респондент, разработчик; API по `https://emocog.example.com/api`.

---

## 2. Требования к VM

- ОС: **Ubuntu 22.04** или **Debian 12** (или аналог).
- Доступ по SSH.
- Открытые порты: **80** (HTTP), **443** (HTTPS). Порт 3000 наружу не открывать (доступ только через nginx).

---

## 3. Подготовка VM

### 3.1 Обновление системы

```bash
sudo apt update && sudo apt upgrade -y
```

### 3.2 Установка Node.js 18+

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
node -v   # должно быть v18 или выше
npm -v
```

### 3.3 Установка PostgreSQL

```bash
sudo apt install -y postgresql postgresql-contrib
sudo systemctl enable postgresql
sudo systemctl start postgresql
```

### 3.4 Создание базы и пользователя для API

```bash
sudo -u postgres psql -c "CREATE USER emocog WITH PASSWORD 'ваш_надёжный_пароль';"
sudo -u postgres psql -c "CREATE DATABASE emocog OWNER emocog;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE emocog TO emocog;"
```

Пароль замените на свой и сохраните (он понадобится в `.env`).

### 3.5 Установка Nginx

```bash
sudo apt install -y nginx
sudo systemctl enable nginx
```

### 3.6 (Рекомендуется) Установка PM2 для автозапуска API

```bash
sudo npm install -g pm2
```

---

## 4. Загрузка проекта на VM

### 4.1 Каталог для сайта

На VM создайте каталог и загрузите туда **содержимое** папки `main` (всё, что внутри: `index.html`, `apps/`, `lib/`, `rt_component-/`, `docs/`, `scripts/` и т.д.). Корневой `index.html` перенаправляет на `apps/web/index.html`.

**Вариант A: с вашего компьютера по SCP**

На локальной машине (в каталоге, где лежит папка `main`):

```bash
scp -r main/* user@IP_ВАШЕЙ_VM:/var/www/emocog/
```

Если на VM ещё нет каталога:

```bash
ssh user@IP_ВАШЕЙ_VM "sudo mkdir -p /var/www/emocog && sudo chown $USER:$USER /var/www/emocog"
scp -r main/* user@IP_ВАШЕЙ_VM:/var/www/emocog/
```

**Вариант B: через git**

На VM:

```bash
sudo mkdir -p /var/www/emocog
sudo chown $USER:$USER /var/www/emocog
cd /var/www
# если репозиторий с проектом уже есть:
git clone <url-репозитория> temp && cp -r temp/main/* emocog/ && rm -rf temp
```

В итоге структура должна быть такой:

```
/var/www/emocog/
├── index.html              # редирект на apps/web/index.html
├── apps/
│   ├── web/                # главный сайт: лэндинг, исследователь, разработчик
│   │   ├── index.html
│   │   ├── researcher.html
│   │   ├── developer.html
│   │   └── developer/
│   │       ├── login.html
│   │       ├── rt-test.html
│   │       ├── rt-test.js
│   │       ├── bpm-test.html
│   │       └── bpm-test.js
│   ├── api/                # Node.js API
│   └── participant-web/   # интерфейс респондента
├── lib/
│   └── rppg_alg_qc_test_web_alg_test_v10/   # движок BPM/rPPG
├── rt_component-/          # Python RT-аналитика (опционально)
└── ...
```

---

## 5. Настройка API

### 5.1 Переменные окружения

```bash
cd /var/www/emocog/apps/api
cp .env.example .env
nano .env
```

Заполните (подставьте свои значения):

```env
DATABASE_URL=postgres://emocog:ваш_надёжный_пароль@localhost:5432/emocog
NODE_ENV=production
PORT=3000
JWT_SECRET=сложный-секрет-не-менее-32-символов-для-jwt
JWT_EXPIRES_IN=7d
FORCE_HTTPS=true
```

Сохраните файл (Ctrl+O, Enter, Ctrl+X в nano).

### 5.2 Установка зависимостей и миграции

```bash
cd /var/www/emocog/apps/api
npm install
npm run migrate:up
```

Если миграции уже применялись, команда просто сообщит об этом.

### 5.3 Проверка запуска API

```bash
node server_phase4_updated.js
```

В консоли должно появиться: `Emocog API (Phase 4) listening on port 3000`. Остановите сервер (Ctrl+C).

### 5.4 Запуск API через PM2 (автозапуск при перезагрузке)

```bash
cd /var/www/emocog/apps/api
pm2 start server_phase4_updated.js --name emocog-api
pm2 save
pm2 startup
```

Команду `pm2 startup` выполните так, как она выведет (обычно нужно вставить предложенную команду с `sudo`). После перезагрузки VM API должен подниматься сам.

Проверка:

```bash
pm2 status
curl -s http://localhost:3000/health
curl -s http://localhost:3000/ready
```

---

## 6. Настройка Nginx

### 6.1 Конфиг сайта (без SSL, для начала)

Создайте конфиг (подставьте ваш домен или IP):

```bash
sudo nano /etc/nginx/sites-available/emocog
```

Содержимое (замените `emocog.example.com` на ваш домен или IP):

```nginx
server {
    listen 80;
    server_name emocog.example.com;

    root /var/www/emocog;
    index index.html;

    # Проверка домена Let's Encrypt (для certbot)
    location ^~ /.well-known/acme-challenge/ {
        root /var/www/emocog;
        allow all;
        default_type "text/plain";
    }

    # Статика: все файлы из main
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Проксирование API
    location /api/ {
        proxy_pass http://127.0.0.1:3000/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Кэш статики (опционально)
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff2)$ {
        expires 7d;
        add_header Cache-Control "public, immutable";
    }
}
```

Включите сайт и проверьте конфиг:

```bash
sudo ln -s /etc/nginx/sites-available/emocog /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

Откройте в браузере: `http://emocog.example.com` (или `http://IP_VM`). Корневой `index.html` перенаправит на `apps/web/index.html` — откроется лэндинг. Проверьте: `http://emocog.example.com/api/health` — должен ответить API.

**Опционально (красивые URL без `/apps/web/` в пути):** можно отдавать лэндинг с корня, задав в nginx `root /var/www/emocog/apps/web;` для `location /` и добавив `location /participant-web { alias /var/www/emocog/apps/participant-web; }`. Тогда в `apps/web/index.html` ссылку на респондента нужно сделать абсолютной: `href="/participant-web/run_new.html"`.

#### BPM / rPPG: каталог `lib/` и URL вида `/main/lib/...`

Динамический импорт движка идёт на `…/lib/rppg_alg_qc_test_web_alg_test_v10/rppg_alg/index.js` (рядом с `apps/` внутри развёрнутого `main`). Если в nginx для префикса `/main/` используется **`alias` только на `apps/web`**, запрос к `/main/lib/...` даст **404**, в консоли будет `Failed to fetch dynamically imported module`, камера в BPM-тесте не стартует до загрузки движка.

**Исправление:** отдельно отдать реальный каталог `lib` (путь на диске — тот же уровень, что и `apps`):

```nginx
# Пример: префикс сайта /main/, файлы лежат в /var/www/emocog/ (там же lib/ и apps/)
location ^~ /main/lib/ {
    alias /var/www/emocog/lib/;
}
```

Подставьте вместо `/var/www/emocog` фактический путь к корню развёрнутого содержимого папки `main`. Проверка в браузере: открыть `https://ваш-домен/main/lib/rppg_alg_qc_test_web_alg_test_v10/rppg_alg/index.js` — должен отдаваться JavaScript, не страница 404.

Если статика отдаётся с `root /var/www/emocog` и URL `/main/...` маппится на этот корень целиком, отдельный `location` для `lib` не нужен.

### 6.2 HTTPS (Let's Encrypt)

Если у вас есть домен, указывающий на IP VM:

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d emocog.example.com
```

Следуйте подсказкам. Certbot сам настроит SSL и редирект с HTTP на HTTPS.

После этого в конфиге Nginx появится блок `listen 443 ssl`. Проверьте: `https://emocog.example.com`, `https://emocog.example.com/api/health` и `https://emocog.example.com/api/ready`.

**Важно:** конфиг из шага 6.1 должен содержать только блок `server { listen 80; ... }`. Не добавляйте вручную строки с `listen 443`, `ssl_certificate`, `include /etc/letsencrypt/options-ssl-nginx.conf` — их добавляет certbot при первом запуске. Файл `options-ssl-nginx.conf` создаётся certbot’ом; если он прописан в конфиге до запуска certbot, nginx не стартует и certbot не сможет получить сертификат.

#### Если уже появилась ошибка «options-ssl-nginx.conf failed (No such file or directory)»

В конфиг были добавлены SSL-директивы до запуска certbot. Верните конфиг к виду «только HTTP»:

1. Откройте конфиг: `sudo nano /etc/nginx/sites-available/emocog`
2. Удалите или закомментируйте весь блок с `listen 443 ssl`, а также строки вида:
   - `include /etc/letsencrypt/options-ssl-nginx.conf;`
   - `ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;`
   - `ssl_certificate` / `ssl_certificate_key`
3. Оставьте один блок `server { listen 80; server_name wecog.ru; ... }` (как в разделе 6.1, с вашим доменом).
4. Проверьте и перезагрузите nginx:
   ```bash
   sudo nginx -t && sudo systemctl reload nginx
   ```
5. Запустите certbot — он сам добавит HTTPS и создаст нужные файлы:
   ```bash
   sudo certbot --nginx -d wecog.ru
   ```

#### Если certbot пишет «Invalid response... 404» для /.well-known/acme-challenge/

Запрос проверки домена не доходит до ответа: либо `location /` отдаёт не тот файл, либо плагин nginx не смог подставить свой location. Сделайте проверку через webroot:

1. **Каталог для проверки** (certbot будет класть сюда временные файлы):
   ```bash
   sudo mkdir -p /var/www/emocog/.well-known/acme-challenge
   sudo chown -R www-data:www-data /var/www/emocog/.well-known
   ```

2. **В конфиге сайта** (`sudo nano /etc/nginx/sites-available/emocog`) в блоке `server { listen 80; ... }` добавьте **до** `location /`:
   ```nginx
   location ^~ /.well-known/acme-challenge/ {
       root /var/www/emocog;
       allow all;
       default_type "text/plain";
   }
   ```

3. **Проверка и перезагрузка nginx:**
   ```bash
   sudo nginx -t && sudo systemctl reload nginx
   ```

4. **Получение сертификата через webroot** (подставьте свой домен):
   ```bash
   sudo certbot certonly --webroot -w /var/www/emocog -d wecog.ru
   ```

5. **Установка сертификата в nginx** (добавит `listen 443`, редирект и т.д.):
   ```bash
   sudo certbot --nginx -d wecog.ru
   ```
   Certbot увидит существующий сертификат и предложит настроить nginx для HTTPS — согласитесь.

**Если 404 остаётся после добавления location:** запросы к домену может обрабатывать другой конфиг (например `default` или отдельный сайт `wecog.ru`). Сделайте два шага.

   **Шаг A — добавить один и тот же location во все конфиги, слушающие 80.** Используйте `alias`, чтобы путь к файлу не зависел от `root` блока:
   ```nginx
   location ^~ /.well-known/acme-challenge/ {
       alias /var/www/emocog/.well-known/acme-challenge/;
       allow all;
       default_type "text/plain";
   }
   ```
   Добавьте этот блок в **каждый** `server { listen 80; ... }` в файлах:
   - `/etc/nginx/sites-available/emocog`
   - `/etc/nginx/sites-available/default`
   - `/etc/nginx/sites-available/wecog.ru` (если есть)
   В каждом случае вставьте блок **до** любого `location /`. Затем:
   ```bash
   sudo nginx -t && sudo systemctl reload nginx
   ```

   **Шаг B — проверить с сервера.** В одном терминале запустите certbot (он создаст файл и будет ждать проверки):
   ```bash
   sudo certbot certonly --webroot -w /var/www/emocog -d wecog.ru
   ```
   Пока certbot ждёт, в **другом** терминале на том же сервере выполните (подставьте токен из вывода certbot или из `ls` ниже):
   ```bash
   ls -la /var/www/emocog/.well-known/acme-challenge/
   curl -s -o /dev/null -w "%{http_code}" -H "Host: wecog.ru" http://127.0.0.1/.well-known/acme-challenge/ИМЯ_ФАЙЛА
   ```
   Если `curl` вернул `404`, запрос обрабатывает не тот server block — добавьте блок с `alias` в `default` (и в любой другой конфиг с `listen 80`). Если вернул `200`, с сервера всё отдаётся верно; тогда возможны прокси/файрвол снаружи (редко).

---

## 7. Настройка фронта под ваш домен

Чтобы «Исследователь», «Респондент» и Sandbox работали с одним доменом и API, в браузере на странице исследователя откройте консоль (F12) и выполните один раз (подставьте ваш домен):

```javascript
window.API_BASE = 'https://emocog.example.com/api';
window.PARTICIPANT_RUN_BASE = 'https://emocog.example.com/apps/participant-web';
```

Либо можно задать эти переменные в коде (см. ниже), тогда не нужно вводить их вручную.

### 7.1 (Опционально) Прописать настройки в коде

Чтобы не вводить `API_BASE` и `PARTICIPANT_RUN_BASE` в консоли, можно задать их по умолчанию в `researcher.html`. Найдите в файле строки вида:

```javascript
window.API_BASE = window.API_BASE || '';
```

Замените на (подставьте ваш домен):

```javascript
window.API_BASE = window.API_BASE || 'https://emocog.example.com/api';
window.PARTICIPANT_RUN_BASE = window.PARTICIPANT_RUN_BASE || 'https://emocog.example.com/apps/participant-web';
```

Для страницы респондента (`apps/participant-web/run_new.html`) загрузка протокола по коду идёт через тот же API. В `js/protocol-runner-new.js` используется `PROTOCOL_RUN_API_BASE || API_BASE`. Если исследователь и респондент открываются с одного домена и вы задали `API_BASE` как выше, то для респондента можно в консоли задать:

```javascript
window.PROTOCOL_RUN_API_BASE = 'https://emocog.example.com/api';
```

Либо добавить в начало скрипта в `run_new.html` (перед вызовом `ProtocolRunner.loadByCode`):

```html
<script>
  window.PROTOCOL_RUN_API_BASE = window.PROTOCOL_RUN_API_BASE || 'https://emocog.example.com/api';
</script>
```

(подставьте свой домен).

---

## 8. Первый пользователь (исследователь)

API не создаёт пользователя по умолчанию. Чтобы войти в интерфейс исследователя:

1. Откройте `https://ваш-домен/researcher.html`.
2. В консоли (F12) задайте: `window.API_BASE = 'https://ваш-домен/api';`
3. Зарегистрируйте пользователя через API, например в консоли браузера:

```javascript
fetch(window.API_BASE + '/auth/register', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: 'admin@example.com',
    password: 'надёжный_пароль',
    display_name: 'Admin'
  })
}).then(r => r.json()).then(console.log);
```

Публичная регистрация создаёт только безопасную роль по умолчанию (`respondent`). Привилегированные роли назначаются через защищённый endpoint `/auth/users` авторизованным администратором/PI.

4. Затем выполните логин (или используйте отдельную страницу/скрипт для логина). Токен можно сохранить в `localStorage`: после успешного ответа от `/auth/login` задайте `window.API_TOKEN = 'полученный_jwt'` или сохраните в `localStorage.emocog_api_token`.

---

## 9. Проверка после деплоя

| Действие | Ожидание |
|----------|----------|
| Открыть `https://ваш-домен/` | Лэндинг: Исследователь, Респондент, Разработчик |
| Открыть `https://ваш-домен/researcher.html` | Интерфейс исследователя |
| Открыть `https://ваш-домен/developer.html` | Страница тестов разработчика |
| Открыть `https://ваш-домен/apps/participant-web/run_new.html` | Страница респондента (без кода — сообщение об ошибке нормально) |
| Открыть `https://ваш-домен/api/health` | Ответ liveness от API (JSON) |
| Открыть `https://ваш-домен/api/ready` | Ответ readiness + проверка БД |
| В исследователе: задать API_BASE и залогиниться | Список сессий/протоколов загружается с API |

---

## 10. Полезные команды

```bash
# Статус API
pm2 status
pm2 logs emocog-api

# Перезапуск API
pm2 restart emocog-api

# Логи Nginx
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# Проверка конфига Nginx
sudo nginx -t && sudo systemctl reload nginx
```

---

## 11. Краткий чеклист

1. [ ] VM: Node 18+, PostgreSQL, Nginx установлены  
2. [ ] БД: пользователь и база `emocog` созданы  
3. [ ] Файлы проекта лежат в `/var/www/emocog/` (содержимое `main`)  
4. [ ] В `apps/api` создан `.env`, выполнены `npm install` и `npm run migrate:up`  
5. [ ] API запущен через PM2 и отвечает на `http://localhost:3000/health`  
6. [ ] Nginx: конфиг включён, `nginx -t` без ошибок, reload выполнен  
7. [ ] Сайт открывается по HTTP (и по HTTPS при настроенном certbot)  
8. [ ] В исследователе заданы `API_BASE` и при необходимости `PARTICIPANT_RUN_BASE` (или прописаны в коде)  
9. [ ] Логин в исследователе и загрузка данных с API работают  

После этого единый сайт собран и захостирован на виртуальной машине.

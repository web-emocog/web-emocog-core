# Реструктуризация под деплой

Проект приведен к деплойной структуре: рабочая часть находится в одной корневой папке `main`, а лишние данные вынесены в папку `../лишнее`.

## Текущая структура

- `main/apps/web` — web UI исследователя и лендинг
- `main/apps/participant-web` — web UI респондента
- `main/apps/api` — backend API
- `main/scripts` — служебные скрипты
- `main/docs` — документация
- `main/lib`, `main/ml`, `main/db`, `main/docker` — инфраструктурные и ML-компоненты

## Что вынесено в `лишнее`

- Архивы и импортированные копии репозиториев
- Временные служебные файлы анализа
- Локальные `node_modules` и тестовые отчеты (`playwright-report`, `test-results`)

## Зависимости

Файлы зависимостей сохранены:

- `main/apps/api/package.json`, `main/apps/api/package-lock.json`
- `main/apps/autotests/package.json`, `main/apps/autotests/package-lock.json`

Перед запуском на новой машине установите зависимости:

```bash
cd main/apps/api && npm install
cd ../autotests && npm install
```

Для прод-деплоя обычно достаточно `main/apps/api`.

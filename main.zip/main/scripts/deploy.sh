#!/usr/bin/env bash
#
# EmoCog — единый скрипт установки, деплоя статики и запуска API/сайта.
# Ориентир: main/docs/DEPLOY.md, nginx-emocog-wecog.conf (статика из main, /api → :3000).
#
# Использование:
#   ./deploy.sh help
#   ./deploy.sh install          # npm install в apps/api
#   ./deploy.sh env-init         # скопировать .env.example → .env, если нет .env
#   ./deploy.sh migrate          # node-pg-migrate up
#   ./deploy.sh start-api        # API в фоне (Phase 4), лог в main/.run/api.log
#   ./deploy.sh start-api -f     # API на переднем плане
#   ./deploy.sh stop-api
#   ./deploy.sh status           # PID + curl /health и /ready
#   ./deploy.sh serve [порт]     # раздача каталога main (python http.server), по умол. 8080
#   ./deploy.sh dev [порт]       # API в фоне + статика на переднем плане (для локальной проверки)
#   ./deploy.sh sync             # rsync каталога main → $EMOCOG_RSYNC_TARGET (см. ниже)
#
# Переменные окружения:
#   EMOCOG_MAIN          — путь к каталогу main (по умол. вычисляется от расположения скрипта)
#   EMOCOG_RSYNC_TARGET  — для sync, напр. user@host:/var/www/emocog
#   EMOCOG_RSYNC_EXTRA   — доп. аргументы rsync (напр. -e "ssh -i key")
#

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_MAIN="$(cd "$SCRIPT_DIR/.." && pwd)"
MAIN_DIR="${EMOCOG_MAIN:-$DEFAULT_MAIN}"
API_DIR="$MAIN_DIR/apps/api"
RUN_DIR="$MAIN_DIR/.run"
PID_FILE="$RUN_DIR/api.pid"
LOG_FILE="$RUN_DIR/api.log"
STATIC_PORT_DEFAULT="${EMOCOG_STATIC_PORT:-8080}"

RED='\033[0;31m'
GRN='\033[0;32m'
YLW='\033[0;33m'
RST='\033[0m'

log() { printf '%b\n' "${GRN}[emocog]${RST} $*"; }
warn() { printf '%b\n' "${YLW}[emocog]${RST} $*" >&2; }
err() { printf '%b\n' "${RED}[emocog]${RST} $*" >&2; }

die() { err "$*"; exit 1; }

ensure_dirs() {
  mkdir -p "$RUN_DIR"
}

read_api_port() {
  local port=3000
  if [[ -f "$API_DIR/.env" ]]; then
    # shellcheck disable=SC2002
    local line
    line="$(grep -E '^[[:space:]]*PORT[[:space:]]*=' "$API_DIR/.env" | tail -1 || true)"
    if [[ -n "$line" ]]; then
      port="${line#*=}"
      port="${port// /}"
      port="${port//\"/}"
    fi
  fi
  echo "$port"
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "Нужна команда: $1"
}

cmd_help() {
  sed -n '2,30p' "$0" | sed 's/^# \{0,1\}//'
}

cmd_install() {
  require_cmd npm
  [[ -d "$API_DIR" ]] || die "Нет каталога API: $API_DIR"
  log "npm install в $API_DIR"
  (cd "$API_DIR" && npm install)
  log "Готово."
}

cmd_env_init() {
  [[ -d "$API_DIR" ]] || die "Нет каталога API: $API_DIR"
  if [[ -f "$API_DIR/.env" ]]; then
    warn ".env уже есть: $API_DIR/.env"
    return 0
  fi
  [[ -f "$API_DIR/.env.example" ]] || die "Нет $API_DIR/.env.example"
  cp "$API_DIR/.env.example" "$API_DIR/.env"
  log "Создан $API_DIR/.env — отредактируйте DATABASE_URL и JWT_SECRET."
}

cmd_migrate() {
  require_cmd npm
  [[ -f "$API_DIR/.env" ]] || die "Нет .env. Выполните: $0 env-init"
  log "Миграции БД (migrate:up)…"
  (cd "$API_DIR" && npm run migrate:up)
  log "Миграции применены."
}

api_start_foreground() {
  require_cmd node
  [[ -f "$API_DIR/server_phase4_updated.js" ]] || die "Нет server_phase4_updated.js"
  (cd "$API_DIR" && exec node server_phase4_updated.js)
}

cmd_start_api() {
  require_cmd node
  ensure_dirs
  if [[ -f "$PID_FILE" ]]; then
    local old
    old="$(cat "$PID_FILE" 2>/dev/null || true)"
    if [[ -n "$old" ]] && kill -0 "$old" 2>/dev/null; then
      die "API уже запущен (PID $old). Сначала: $0 stop-api"
    fi
    rm -f "$PID_FILE"
  fi

  if [[ "${1:-}" == "-f" ]] || [[ "${1:-}" == "--foreground" ]]; then
    log "Запуск API (foreground), Phase 4…"
    (cd "$API_DIR" && exec node server_phase4_updated.js)
    return
  fi

  log "Запуск API (фон), лог: $LOG_FILE"
  nohup bash -c "cd \"$API_DIR\" && exec node server_phase4_updated.js" >>"$LOG_FILE" 2>&1 &
  echo $! >"$PID_FILE"
  sleep 1
  if kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    log "API PID $(cat "$PID_FILE") порт $(read_api_port)"
  else
    err "Процесс завершился сразу. Смотрите $LOG_FILE"
    rm -f "$PID_FILE"
    return 1
  fi
}

cmd_stop_api() {
  if [[ ! -f "$PID_FILE" ]]; then
    warn "PID-файл не найден ($PID_FILE)."
    return 0
  fi
  local pid
  pid="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [[ -z "$pid" ]]; then
    rm -f "$PID_FILE"
    return 0
  fi
  if kill -0 "$pid" 2>/dev/null; then
    log "Останавливаю API (PID $pid)…"
    kill "$pid" 2>/dev/null || true
    sleep 1
    kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null || true
  fi
  rm -f "$PID_FILE"
  log "API остановлен."
}

cmd_status() {
  local port
  port="$(read_api_port)"
  if [[ -f "$PID_FILE" ]]; then
    local pid
    pid="$(cat "$PID_FILE" 2>/dev/null || true)"
    if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
      log "API: работает, PID $pid, порт $port"
    else
      warn "PID-файл есть, но процесс не найден."
    fi
  else
    warn "API: PID-файл отсутствует (возможно, не запускали через этот скрипт)."
  fi
  if command -v curl >/dev/null 2>&1; then
    log "GET http://127.0.0.1:${port}/health"
    curl -sS -m 3 "http://127.0.0.1:${port}/health" && echo || warn "/health недоступен"
    log "GET http://127.0.0.1:${port}/ready"
    curl -sS -m 5 "http://127.0.0.1:${port}/ready" && echo || warn "/ready недоступен (часто из-за БД)"
  else
    warn "curl не установлен — пропуск проверки HTTP."
  fi
}

cmd_serve() {
  local port="${1:-$STATIC_PORT_DEFAULT}"
  require_cmd python3
  [[ -f "$MAIN_DIR/index.html" ]] || die "Нет $MAIN_DIR/index.html — проверьте EMOCOG_MAIN"
  log "Статика из: $MAIN_DIR"
  log "URL: http://127.0.0.1:${port}/"
  warn "python http.server не проксирует /api → Node. Для связки UI+API без nginx задайте API_BASE / PROTOCOL_RUN_API_BASE (см. main/docs/DEPLOY.md) или используйте nginx как в nginx-emocog-wecog.conf."
  log "Останов: Ctrl+C"
  (cd "$MAIN_DIR" && exec python3 -m http.server "$port" --bind 127.0.0.1)
}

cmd_dev() {
  local port="${1:-$STATIC_PORT_DEFAULT}"
  cmd_start_api
  cleanup() {
    cmd_stop_api
  }
  trap cleanup EXIT INT TERM
  log "Режим dev: API в фоне + статика. После выхода API будет остановлен."
  cmd_serve "$port"
}

cmd_sync() {
  require_cmd rsync
  [[ -n "${EMOCOG_RSYNC_TARGET:-}" ]] || die "Задайте EMOCOG_RSYNC_TARGET, например: user@host:/var/www/emocog"
  log "rsync $MAIN_DIR/ → $EMOCOG_RSYNC_TARGET"
  # Исключаем тяжёлое и локальное; на сервере делается npm install в apps/api при необходимости
  rsync -avz --delete \
    --exclude '.run/' \
    --exclude 'apps/api/node_modules/' \
    --exclude 'apps/autotests/node_modules/' \
    --exclude '.git/' \
    --exclude '**/playwright-report/' \
    --exclude '**/test-results/' \
    $EMOCOG_RSYNC_EXTRA \
    "$MAIN_DIR/" "$EMOCOG_RSYNC_TARGET/"
  log "Синхронизация завершена. На сервере: npm install в apps/api, миграции, nginx + systemd/supervisor для Node."
}

cmd_production_hint() {
  cat <<EOF
Продакшен (как в nginx-emocog-wecog.conf):
  1) Статика: root = каталог с содержимым main (например /var/www/emocog).
  2) location /api/ → proxy_pass http://127.0.0.1:$(read_api_port)/;
  3) API: systemd unit или supervisor с:
       WorkingDirectory=.../main/apps/api
       ExecStart=$(command -v node) server_phase4_updated.js
     и файлом .env рядом.
  4) Локально проверить полный стек:  $0 dev
  5) BPM/rPPG: каталог main/lib/ должен отдаваться по URL /lib/… Если в nginx root = …/apps/web,
     добавьте до location / блок из main/deploy/nginx-snippet-emocog-lib.conf
     (location ^~ /lib/ { alias …/emocog/lib/; }), затем nginx -t && reload.
EOF
}

main() {
  local cmd="${1:-help}"
  shift || true
  case "$cmd" in
    help|-h|--help) cmd_help ;;
    install) cmd_install ;;
    env-init) cmd_env_init ;;
    migrate) cmd_migrate ;;
    start-api) cmd_start_api "$@" ;;
    stop-api) cmd_stop_api ;;
  
    restart-api) cmd_stop_api; sleep 1; cmd_start_api ;;
    status) cmd_status ;;
    serve) cmd_serve "$@" ;;
    dev) cmd_dev "$@" ;;
    sync) cmd_sync ;;
    production-hint|hint) cmd_production_hint ;;
    *) err "Неизвестная команда: $cmd"; cmd_help; exit 1 ;;
  esac
}

main "$@"

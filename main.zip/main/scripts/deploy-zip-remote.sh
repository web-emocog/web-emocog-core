#!/usr/bin/env bash
#
# Единый деплой: zip каталога main → scp на сервер → распаковка в .../web-emocog-core/main → npm + migrate → pm2 + nginx.
#
# По умолчанию сервер тот же, что и ssh -l uskovayuli 158.160.179.184 (промпт uskovayuli@database).
# Достаточно из корня репозитория (рядом с папкой main):
#
#   chmod +x main/scripts/deploy-zip-remote.sh
#   ./main/scripts/deploy-zip-remote.sh
#
# Переопределение при необходимости:
#   EMOCOG_SSH_USER=… EMOCOG_SSH_HOST=… EMOCOG_REMOTE_ROOT=… ./main/scripts/deploy-zip-remote.sh
#   EMOCOG_SSH_PORT=22
#   EMOCOG_SSH_OPTS='-i ~/.ssh/id_ed25519'
#
# Если обычный ssh у вас работает через ~/.ssh/config (другой HostName, ProxyJump, порт, User),
# а скрипт даёт timeout — задайте тот же ярлык, что и вручную:
#   EMOCOG_SSH_CONFIG_HOST=database ./main/scripts/deploy-zip-remote.sh
# (тогда не используются EMOCOG_SSH_USER / EMOCOG_SSH_HOST / EMOCOG_SSH_PORT из скрипта для ssh/scp.)
#
# Запускайте скрипт в том же терминале на ноутбуке, где вы проверяли ssh. Среды без полного
# доступа в сеть (некоторые автозапуски) могут не дотянуться до ВМ при том, что у вас локально всё ок.
#
# Полная очистка main на сервере перед заливкой (.env из API сохраняется):
#   EMOCOG_CLEAN_DEPLOY=1 ./main/scripts/deploy-zip-remote.sh
#
# Порт API: в приоритете PORT из apps/api/.env (как у server.js). EMOCOG_API_PORT — запасной
# вариант, если в .env PORT нет (по умолчанию 3000, как в .env.example). Не 5000, если в .env 3000.
#
set -euo pipefail

# Прямое подключение (без учёта Host из ~/.ssh/config), эквивалент: ssh -l uskovayuli 158.160.179.184
EMOCOG_SSH_USER="${EMOCOG_SSH_USER:-uskovayuli}"
EMOCOG_SSH_HOST="${EMOCOG_SSH_HOST:-158.160.179.184}"
EMOCOG_SSH_PORT="${EMOCOG_SSH_PORT:-22}"
# Непустое значение = имя Host из ~/.ssh/config (scp/ssh как «ssh это_имя»)
EMOCOG_SSH_CONFIG_HOST="${EMOCOG_SSH_CONFIG_HOST:-}"
# Родитель каталога main на сервере (рядом лежит main/apps, main/scripts, …)
EMOCOG_REMOTE_ROOT="${EMOCOG_REMOTE_ROOT:-/home/uskovayuli/web-emocog-core}"
EMOCOG_SSH_OPTS="${EMOCOG_SSH_OPTS:--o StrictHostKeyChecking=accept-new -o ConnectTimeout=15}"
EMOCOG_API_PORT="${EMOCOG_API_PORT:-3000}"
EMOCOG_PM2_NAME="${EMOCOG_PM2_NAME:-emocog-api}"
EMOCOG_CLEAN_DEPLOY="${EMOCOG_CLEAN_DEPLOY:-0}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAIN_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
ZIP_NAME="emocog-main-$(date +%Y%m%d-%H%M%S).zip"
TMP_ZIP="${TMPDIR:-/tmp}/$ZIP_NAME"

RED='\033[0;31m'
GRN='\033[0;32m'
RST='\033[0m'
log() { printf '%b\n' "${GRN}[deploy-zip]${RST} $*"; }
err() { printf '%b\n' "${RED}[deploy-zip]${RST} $*" >&2; }
die() { err "$*"; exit 1; }

[[ -d "$MAIN_DIR/apps" ]] || die "Ожидается каталог main с apps/: $MAIN_DIR"
command -v zip >/dev/null || die "Нужен zip"
command -v scp >/dev/null || die "Нужен scp"
command -v ssh >/dev/null || die "Нужен ssh"

log "Упаковка $MAIN_DIR → $TMP_ZIP (без node_modules, .git, .env)"
rm -f "$TMP_ZIP"
(cd "$MAIN_DIR" && zip -r "$TMP_ZIP" . \
  -x "node_modules/*" \
  -x "**/node_modules/*" \
  -x ".git/*" \
  -x "**/.git/*" \
  -x ".cursor/*" \
  -x ".run/*" \
  -x "dist/*" \
  -x "build/*" \
  -x "*.zip" \
  -x ".env" \
  -x "apps/api/.env" \
  -q)

if [[ -n "$EMOCOG_SSH_CONFIG_HOST" ]]; then
  SCP_DST="${EMOCOG_SSH_CONFIG_HOST}:/tmp/$ZIP_NAME"
  log "Загрузка через SSH config (Host $EMOCOG_SSH_CONFIG_HOST) → /tmp/$ZIP_NAME"
  scp $EMOCOG_SSH_OPTS "$TMP_ZIP" "$SCP_DST"
else
  log "Загрузка: ${EMOCOG_SSH_USER}@${EMOCOG_SSH_HOST}:${EMOCOG_SSH_PORT} → /tmp/$ZIP_NAME"
  scp $EMOCOG_SSH_OPTS -P "$EMOCOG_SSH_PORT" "$TMP_ZIP" "${EMOCOG_SSH_USER}@${EMOCOG_SSH_HOST}:/tmp/$ZIP_NAME"
fi

REMOTE_B64=$(printf '%s' "$EMOCOG_REMOTE_ROOT" | base64 | tr -d '\n')

if [[ -n "$EMOCOG_SSH_CONFIG_HOST" ]]; then
  log "Распаковка и перезапуск API (SSH config: $EMOCOG_SSH_CONFIG_HOST)…"
  SSH_CMD=(ssh $EMOCOG_SSH_OPTS "$EMOCOG_SSH_CONFIG_HOST")
else
  log "Распаковка и перезапуск API на сервере (${EMOCOG_SSH_USER}@${EMOCOG_SSH_HOST}, порт ${EMOCOG_SSH_PORT})…"
  SSH_CMD=(ssh $EMOCOG_SSH_OPTS -p "$EMOCOG_SSH_PORT" -l "$EMOCOG_SSH_USER" "$EMOCOG_SSH_HOST")
fi

"${SSH_CMD[@]}" "REMOTE_ROOT_B64=$REMOTE_B64 ZIP_NAME='$ZIP_NAME' PORT='$EMOCOG_API_PORT' PM2N='$EMOCOG_PM2_NAME' CLEAN='$EMOCOG_CLEAN_DEPLOY' bash -s" <<'REMOTE'
set -euo pipefail
ROOT="$(printf '%s' "$REMOTE_ROOT_B64" | base64 -d 2>/dev/null || printf '%s' "$REMOTE_ROOT_B64" | base64 -D 2>/dev/null || true)"
[[ -n "$ROOT" ]] || { echo "Пустой REMOTE_ROOT после base64"; exit 1; }
ZIP="/tmp/${ZIP_NAME}"
MAIN_DIR="$ROOT/main"
API_DIR="$MAIN_DIR/apps/api"

[[ -f "$ZIP" ]] || { echo "Нет архива: $ZIP"; exit 1; }

ENV_BACKUP=""
if [[ -f "$API_DIR/.env" ]]; then
  ENV_BACKUP="$(mktemp)"
  cp "$API_DIR/.env" "$ENV_BACKUP"
fi

if [[ "${CLEAN:-0}" == "1" ]]; then
  echo "[deploy-zip] CLEAN: останавливаю PM2 и удаляю $MAIN_DIR"
  pm2 delete "$PM2N" 2>/dev/null || true
  rm -rf "$MAIN_DIR"
fi

mkdir -p "$MAIN_DIR"
cd "$MAIN_DIR"
unzip -o -q "$ZIP"

if [[ -n "${ENV_BACKUP:-}" && -f "$ENV_BACKUP" ]]; then
  mkdir -p "$API_DIR"
  cp "$ENV_BACKUP" "$API_DIR/.env"
  rm -f "$ENV_BACKUP"
fi

cd "$API_DIR"
npm install --omit=dev
if [[ -f .env ]]; then
  npm run migrate -- up --envPath .env 2>/dev/null || npm run migrate:up 2>/dev/null || true
fi

# Совпадает с config/index.js: dotenv .env, иначе PORT из переменной деплоя
LISTEN_PORT=""
if [[ -f .env ]]; then
  LISTEN_PORT="$(node -e "require('./load-env'); process.stdout.write(String(process.env.PORT || '').trim())" 2>/dev/null || true)"
fi
if [[ -z "$LISTEN_PORT" ]]; then
  LISTEN_PORT="${PORT:-3000}"
fi
case "$LISTEN_PORT" in ''|*[!0-9]*) LISTEN_PORT="${PORT:-3000}" ;; esac
export PORT="$LISTEN_PORT"
export HOST="${HOST:-0.0.0.0}"
echo "[deploy-zip] PORT=$PORT HOST=$HOST (как у PM2 / nginx upstream)"

echo "[deploy-zip] Проверка: Node загружает .env + config (иначе процесс падает до listen)…"
if ! node -e "require('./config');" 2>"/tmp/emocog-deploy-cfg.err"; then
  echo "[deploy-zip] ОШИБКА загрузки API. Частые причины: NODE_ENV=production и короткий/пустой JWT_SECRET (нужно ≥32 символов), неверный .env."
  cat "/tmp/emocog-deploy-cfg.err"
  rm -f "/tmp/emocog-deploy-cfg.err"
  exit 1
fi
rm -f "/tmp/emocog-deploy-cfg.err"

pm2 delete "$PM2N" 2>/dev/null || true
pm2 start "$API_DIR/server.js" --name "$PM2N" --cwd "$API_DIR" --update-env
pm2 save

if command -v sudo >/dev/null && sudo -n true 2>/dev/null; then
  sudo nginx -t && sudo systemctl reload nginx
else
  nginx -t 2>/dev/null && systemctl reload nginx 2>/dev/null || true
fi

sleep 2
echo "--- PM2 ($PM2N) ---"
pm2 describe "$PM2N" 2>/dev/null | head -n 25 || true

# Как nginx: при FORCE_HTTPS приложение ждёт X-Forwarded-Proto: https
echo "--- local health (127.0.0.1:$PORT) ---"
if curl -sfS -m 8 -H "X-Forwarded-Proto: https" "http://127.0.0.1:${PORT}/health" && echo; then
  :
else
  echo "[deploy-zip] /health недоступен. Последние строки лога PM2:"
  pm2 logs "$PM2N" --lines 35 --nostream 2>/dev/null || true
fi
curl -sfS -m 8 -H "X-Forwarded-Proto: https" "http://127.0.0.1:${PORT}/ready" && echo || true

rm -f "$ZIP"
echo "DEPLOY OK"
REMOTE

rm -f "$TMP_ZIP"
log "Готово. Обнови сайт в браузере с Ctrl+F5."

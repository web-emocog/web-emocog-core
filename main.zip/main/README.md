# EmoCog — main (универсальная сборка)

Web-платформа для когнитивных исследований. Папка **main** содержит полный код для работы и деплоя.

## Архитектура

| Каталог | Назначение |
|---------|------------|
| **apps/web/** | Главный сайт: лэндинг, исследователь, раздел разработчика (логин, RT/BPM тесты) |
| **apps/participant-web/** | Интерфейс респондента: протоколы, MVP, precheck, gaze, QC |
| **apps/api/** | Backend API (Node.js, Фаза 4) |
| **lib/** | Библиотеки (rPPG/BPM для теста разработчика) |
| **rt_component-/** | Python RT-аналитика (офлайн) |

Корневой **index.html** перенаправляет на **apps/web/index.html**.

## Точки входа

| URL / путь | Назначение |
|------------|------------|
| `/` → `apps/web/index.html` | Лэндинг: Исследователь, Респондент, Разработчик |
| `apps/web/researcher.html` | Интерфейс исследователя |
| `apps/web/developer.html` | Тесты модулей (после входа) |
| `apps/web/developer/login.html` | Вход в раздел разработчика |
| `apps/participant-web/run_new.html` | Респондент: протокол по коду `?code=...` |
| `apps/participant-web/mvp_with_precheck_1-updated.html` | Полный MVP |

## Деплой

См. **HOSTING.md** (развёртывание на VM) и **DEPLOY.md** (настройка API_BASE, PARTICIPANT_RUN_BASE). Проверка полноты — **MAIN_CHECKLIST.md**.
